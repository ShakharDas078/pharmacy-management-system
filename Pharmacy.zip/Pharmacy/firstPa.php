<!DOCTYPE html>
<html>
<head>
 <title> First</title>
 <link rel="stylesheet" href="firstPa.css">
</head>
<body>
<ul>
  <li><a href="firstPa.php">Home</a></li>
  <li><a href="Registration.php">Sign Up</a></li>
  <li><a href="login.php">Login</a></li>
  <li style="float:right"><a class="active" href="#about">About</a></li>
</ul>
    <div>
        <h1>Hello </h1>
    </div>
</body>
</html>



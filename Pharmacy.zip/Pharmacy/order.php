<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Order</title>
</head>
<body>
    <h2>Order</h2>
    <form method="POST" action="order.php">
        <input type="text" name="drugId" placeholder="Drug ID " required><br><br>
        <input type="text" id="customer_id" name="customer_id" placeholder="Customer ID" required><br><br>
        <input type="text" id="paymentStatus" name="paymentStatus" placeholder="Payment Status" required><br><br>
        <input type="text" id="deliveryStatus" name="deliveryStatus" placeholder="Delivery Status" required><br><br>
        <input type="date" id="orderDate" name="orderDate" placeholder="Order Date" required><br><br>
        
        <input type="submit" name="submitOrder" value="Order">
        <button name="submitPayment"><a href="payment.php">Payment</a></button>
    </form>
</body>
</html>


<?php
include("connection.php"); // Include your database connection file

// Function to generate a unique order ID
function generateOrderId() {
    return uniqid();
}

// Function to simulate payment processing
function processPayment($orderId) {
    // Simulate successful payment processing
    // Replace this with your actual payment processing logic
    return true;
}

// Check if form is submitted for order placement
if (isset($_POST["submitOrder"])) {
    // Retrieve form data
    $drugId = $_POST["drugId"];
    $customer_id = $_POST["customer_id"];
    $paymentStatus = $_POST["paymentStatus"];
    $deliveryStatus = $_POST["deliveryStatus"];
    $orderDate = $_POST["orderDate"];

    // Check if the drugId exists in the drugs table
    $drugQuery = "SELECT * FROM drugs WHERE drugId = '$drugId'";
    $resultDrug = mysqli_query($conn, $drugQuery);

    // Check if the customer_id exists in the customers table
    $customerQuery = "SELECT * FROM customers WHERE customer_id = '$customer_id'";
    $resultCustomer = mysqli_query($conn, $customerQuery);

    // If both drugId and customer_id exist, proceed with inserting the order
    if (mysqli_num_rows($resultDrug) > 0 && mysqli_num_rows($resultCustomer) > 0) {
        // Generate a unique order ID
        $orderId = generateOrderId();

        // SQL insert query for orders table
        $sql = "INSERT INTO orders (orderId, drugId, customer_id, paymentStatus, deliveryStatus, orderDate)
                VALUES ('$orderId', '$drugId', '$customer_id', '$paymentStatus', '$deliveryStatus', '$orderDate')";

        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // Redirect to payment page
            header("Location: payment.php?orderId=$orderId");
            exit(); // Make sure to exit after redirection
        } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Error: Drug ID or Customer ID does not exist";
    }
}

// Close the database connection
mysqli_close($conn);
?>

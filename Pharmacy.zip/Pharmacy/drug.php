<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Drug</title>
</head>
<body>
    <h2>Add New Drug</h2>
    <form  method="POST">
            <input type="text" id="name" name="name" placeholder="Drug Name" required><br><br>
        
            <input type="number" id="quantity" name="quantity" placeholder=" Drug Quantity"  required><br><br>
      
            <input type="number" step="0.01" id="price" name="price" placeholder="Price Tk " required><br><br>
       
            <input type="date" id="expiry_date" name="expiry_date" placeholder="Expiry Date" required><br><br>
       
            <textarea id="description" name="description" placeholder="Drug Description" required></textarea><br><br>
        
            <input type="submit" value="Save">
       
    </form>
</body>
</html>


<?php
// Include the database connection file
include("connection.php");

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $quantity = $_POST["quantity"];
    $price = $_POST["price"];
    $expiry_date = $_POST["expiry_date"];
    $description = $_POST["description"];
    
$sql = "SELECT COUNT(*) AS total FROM drugs";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$sequential_digits = str_pad($row['total'] + 1, 2, '0', STR_PAD_LEFT);

// Generate first 4 digits of customer ID (current year and month)
$current_year_month = date("ym");

// Combine first 4 digits with sequential digits to create customer ID
$drugId  = $current_year_month . $sequential_digits;

    // SQL insert query
    $sql = "INSERT INTO drugs (drugId, name, quantity, price, expiry_date, description)
    VALUES ('$drugId', '$name', '$quantity', '$price', '$expiry_date', '$description')";


    // Execute the query
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully ";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
    
    // Close the database connection
    mysqli_close($conn);
}
?>

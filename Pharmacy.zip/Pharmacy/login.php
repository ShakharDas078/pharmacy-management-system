

<!DOCTYPE html>
<head>

    <title>Login Form</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <form  method="post">
            <h2>Login</h2>
            <div class="input-group">
                <label for="phone">Phone </label>
                <input type="phone" id="phone" name="phone" required>
            </div>
            <div class="input-group">
                <label for="password">Password </label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>

<?php
include("connection.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get phone and password from the form
    $phone = $_POST["phone"];
    $password = $_POST["password"];

    // SQL query to check if the phone and password match
    $query = "SELECT * FROM Customers WHERE phone = '$phone' AND password = '$password'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        
        // Phone and password match
        // Redirect the user to the dashboard or home page
       header("Location:view.php");
     exit();
    } else {
        // Phone and password don't match
        // Display an error message
        echo "Invalid phone or password";
    }
}
?>

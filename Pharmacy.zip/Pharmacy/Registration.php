

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Registration</title>
</head>
<body>
    <h2>Customer Registration</h2>
    <form  method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br><br>
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>
        <label for="phone">Phone:</label>
        <input type="text" id="phone" name="phone" required><br><br>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>
        <label for="address">Address:</label>
        <input type="text" id="address" name="address" required><br><br>
        <input type="submit" value="Register">
        <a href="firstPa.php">Back</a>
    </form>
</body>
</html>




<?php
include("connection.php");
$username = $_POST['username'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$password = $_POST['password'];
$address = $_POST['address'];


$sql = "SELECT COUNT(*) AS total FROM Customers";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$sequential_digits = str_pad($row['total'] + 1, 2, '0', STR_PAD_LEFT);

// Generate first 4 digits of customer ID (current year and month)
$current_year_month = date("ym");

// Combine first 4 digits with sequential digits to create customer ID
$customer_id = $current_year_month . $sequential_digits;

// SQL to insert data into table
$sql = "INSERT INTO Customers (customer_id, username, email, phone, password, address)
        VALUES ('$customer_id', '$username', '$email', '$phone', '$password', '$address')";

if ($conn->query($sql) === TRUE) {
     echo "Ok ";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
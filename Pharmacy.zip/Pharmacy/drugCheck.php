<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Drug Management System</title>
</head>
<body>
    <h2> Drug List</h2>
    <table border="1">
        <tr>
            <th>Drug ID</th>
            <th>Name</th>
            <th>Quantity</th>
            <th>Per Pich</th>
            <th>Expiry Date</th>
            <th>Description</th>
        </tr>
        <?php
        // Include the database connection file
        include("connection.php");

        // SQL query to retrieve drugs data
        $sql = "SELECT * FROM drugs";
        $result = mysqli_query($conn, $sql);

        // Check if any records found
        if (mysqli_num_rows($result) > 0) {
            // Loop through each row of the result set
            while ($row = mysqli_fetch_assoc($result)) {
                // Output data for each row
                echo "<tr>";
                echo "<td>" . $row["drugId"] . "</td>";
                echo "<td>" . $row["name"] . "</td>";
                echo "<td>" . $row["quantity"] . "</td>";
                echo "<td>" . $row["price"] . "</td>";
                echo "<td>" . $row["expiry_date"] . "</td>";
                echo "<td>" . $row["description"] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='6'>No drugs found</td></tr>";
        }

        // Close the database connection
        mysqli_close($conn);
        ?>
    </table>
</body>
</html>

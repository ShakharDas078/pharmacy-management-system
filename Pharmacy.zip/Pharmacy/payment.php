<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Payment</title>
</head>
<body>
    <h2>Add New Payment</h2>
    <form method="POST">
        <input type="text" id="orderId" name="orderId" placeholder="Order ID" required><br><br>
        <input type="number" id="amount" name="amount" placeholder="Amount" step="0.01" required><br><br>
        <input type="date" id="paymentDate" name="paymentDate" placeholder="Payment Date" required><br><br>
        
        <input type="submit" value="Save">
    </form>
</body>
</html>


<?php
include("connection.php"); 

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $orderId = $_POST["orderId"];
    $amount = $_POST["amount"];
    $paymentDate = $_POST["paymentDate"];

    // SQL insert query for payment table
    $sql = "INSERT INTO payment (orderId, amount, paymentDate)
            VALUES ('$orderId', '$amount', '$paymentDate')";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        echo "New payment record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

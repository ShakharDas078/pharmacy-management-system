<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Details</title>
</head>
<body>
    <h2>Customer Details</h2>

    <form method="GET">
        <label for="customer_id">Enter Customer ID:</label>
        <input type="text" id="customer_id" name="customer_id" required>
        <input type="submit" value="Search">
    </form>

    <?php
    // Include database connection
    include("connection.php");

    // Check if customer_id is provided through GET method
    if(isset($_GET['customer_id'])) {
        $customer_id = $_GET['customer_id'];

        // SQL query to retrieve customer details based on customer_id
        $sql = "SELECT * FROM Customers WHERE customer_id='$customer_id'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Output data of each row in an HTML table
            echo "<h3>Customer Details</h3>";
            echo "<table border='1'>
                    <tr>
                        <th>Customer ID</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                    </tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$row["customer_id"]."</td>
                        <td>".$row["username"]."</td>
                        <td>".$row["email"]."</td>
                        <td>".$row["phone"]."</td>
                        <td>".$row["address"]."</td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "No customer found with this ID";
        }
    }
    // Close database connection
    $conn->close();
    ?>
</body>
</html>
